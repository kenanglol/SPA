Tüm bağlantılar sayfadan sayfaya yapılmamıştır.
SS alınması için tek tek html dosyalarının açılması
gerekmektedir.
